# 🏥 Raghav's Prescription Management System

A comprehensive web-based medical prescription management application built with Java Servlets, JSP, and MySQL. This application provides a secure platform for healthcare management with features including AI-powered symptom checking, appointment booking, prescription management, and multilingual support.

![Java](https://img.shields.io/badge/Java-ED8B00?style=for-the-badge&logo=java&logoColor=white)
![MySQL](https://img.shields.io/badge/MySQL-005C84?style=for-the-badge&logo=mysql&logoColor=white)
![HTML5](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)

## ✨ Features

### 🔐 **Security & Authentication**
- **Secure User Authentication** with PBKDF2 password hashing (120,000 iterations)
- **Session Management** with automatic timeout and regeneration
- **CSRF Protection** on all forms
- **Input Validation** and XSS prevention
- **SQL Injection Protection** using PreparedStatements
- **Environment-based Configuration** for secure credential management

### 🏥 **Healthcare Management**
- **AI Symptom Checker** - Get preliminary health insights based on symptoms
- **Appointment Booking** - Schedule consultations with healthcare providers
- **Digital Prescriptions** - Create and manage electronic prescriptions
- **Medical History** - View prescription history with interactive charts
- **Health Dashboard** - Comprehensive overview of patient health status

### 🌐 **User Experience**
- **Multilingual Support** - English and Hindi (हिन्दी) interface
- **Responsive Design** - Works seamlessly on desktop, tablet, and mobile
- **Real-time Form Validation** - Instant feedback with visual indicators
- **Toast Notifications** - Non-intrusive success/error messages
- **Accessibility** - WCAG compliant with screen reader support
- **Dark Mode Support** - Automatic detection of user preference

### 🤖 **AI & Automation**
- **Intelligent Chatbot** - 24/7 health assistant for basic queries
- **Symptom Analysis** - Pattern-based health condition predictions
- **Automated Notifications** - System health monitoring and alerts

### 📊 **Analytics & Reporting**
- **Interactive Charts** - Visual representation of prescription trends
- **Health Metrics** - Track patient health statistics over time
- **Export Functionality** - Download reports and prescription history

## 🚀 Quick Start

### Prerequisites

Ensure you have the following installed:

- **Java Development Kit (JDK) 8+**
- **Apache Tomcat 9.0+** or any Java Servlet Container
- **MySQL 5.7+** or **MySQL 8.0+**
- **Web Browser** (Chrome, Firefox, Safari, Edge)

### 📋 Installation Guide

#### 1. **Clone the Repository**
```bash
git clone https://github.com/yourusername/raghav-prescription-app.git
cd raghav-prescription-app
```

#### 2. **Database Setup**

**Option A: Using MySQL Command Line**
```bash
# Login to MySQL
mysql -u root -p

# Create database and import schema
mysql -u root -p < SQL/schema.sql

# Optional: Import sample data
mysql -u root -p prescriptiondb < SQL/sample_data.sql
```

**Option B: Using MySQL Workbench**
1. Open MySQL Workbench
2. Connect to your MySQL server
3. Execute the contents of `SQL/schema.sql`
4. Verify tables are created: `users`, `appointments`, `prescription`

#### 3. **Environment Configuration**

Create environment variables for secure database connection:

**Windows (Command Prompt):**
```cmd
set DB_URL=jdbc:mysql://localhost:3306/prescriptiondb?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC
set DB_USER=root
set DB_PASSWORD=your_mysql_password
```

**Windows (PowerShell):**
```powershell
$env:DB_URL="jdbc:mysql://localhost:3306/prescriptiondb?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC"
$env:DB_USER="root"
$env:DB_PASSWORD="your_mysql_password"
```

**Linux/macOS:**
```bash
export DB_URL="jdbc:mysql://localhost:3306/prescriptiondb?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC"
export DB_USER="root"
export DB_PASSWORD="your_mysql_password"
```

**Alternative: System Properties**
You can also set these as JVM system properties:
```bash
-Ddb.url="jdbc:mysql://localhost:3306/prescriptiondb"
-Ddb.user="root"
-Ddb.password="your_password"
```

#### 4. **Application Deployment**

**Option A: Using Eclipse IDE (Recommended for Development)**
1. Import the project into Eclipse IDE
2. Right-click project → **Properties** → **Project Facets**
3. Ensure **Java** and **Dynamic Web Module** are enabled
4. Right-click project → **Run As** → **Run on Server**
5. Select **Apache Tomcat** and configure if needed
6. Access application at: `http://localhost:8080/PrescriptionApp`

**Option B: Manual WAR Deployment**
1. Create WAR file:
   ```bash
   # If using Maven
   mvn clean package
   
   # Or export WAR from Eclipse: File → Export → Web → WAR file
   ```
2. Copy WAR to Tomcat webapps directory:
   ```bash
   cp PrescriptionApp.war $TOMCAT_HOME/webapps/
   ```
3. Start Tomcat:
   ```bash
   $TOMCAT_HOME/bin/startup.sh  # Linux/macOS
   $TOMCAT_HOME/bin/startup.bat # Windows
   ```
4. Access at: `http://localhost:8080/PrescriptionApp`

### 🔧 Configuration

#### Database Configuration
The application supports flexible database configuration:

1. **Environment Variables** (Recommended for Production)
   - `DB_URL` - Database connection URL
   - `DB_USER` - Database username  
   - `DB_PASSWORD` - Database password

2. **System Properties** (Alternative)
   - `db.url` - Database connection URL
   - `db.user` - Database username
   - `db.password` - Database password

3. **Default Values** (Development Only)
   - URL: `jdbc:mysql://localhost:3306/prescriptiondb`
   - User: `root`
   - Password: Must be provided via environment variable

## 🏗️ Architecture Overview

### Technology Stack
- **Backend**: Java Servlets 4.0.1, JSP 2.3
- **Frontend**: HTML5, CSS3, JavaScript ES6+
- **Database**: MySQL 8.0
- **Server**: Apache Tomcat 9.0+
- **Security**: PBKDF2, CSRF Protection, Session Management
- **Charts**: Chart.js for data visualization

### Project Structure
```
raghavproject/
├── src/com/raghav/prescription/     # Java source files
│   ├── *.java                      # Servlets and utility classes
├── WebContent/                      # Web resources
│   ├── *.jsp                       # JSP pages
│   ├── scripts/                    # JavaScript files
│   ├── error/                      # Custom error pages
│   ├── lang/                       # Internationalization files
│   ├── style.css                  # Main stylesheet
│   └── WEB-INF/
│       ├── web.xml                 # Servlet configuration
│       ├── classes/                # Compiled Java classes
│       └── lib/                    # Runtime libraries
├── SQL/                            # Database scripts
│   ├── schema.sql                  # Database schema
│   └── migration_v2.sql           # Schema updates
├── lib/                           # Build-time libraries
└── README.md                      # This file
```

## 🔧 Usage Guide

### For Patients

#### 1. **Registration & Login**
1. Visit the application homepage
2. Click **"Register"** to create a new account
3. Provide full name, email, and secure password
4. Login with your credentials

#### 2. **Using AI Symptom Checker**
1. Navigate to **Dashboard** → **AI Symptom Checker**
2. Describe your symptoms in the text area
3. Click **"Analyze Symptoms"**
4. Review the AI-generated health insights
5. **Note**: This is for informational purposes only

#### 3. **Booking Appointments**
1. Go to **Dashboard** → **Book Appointment**
2. Fill in patient details and preferred date/time
3. Provide reason for consultation
4. Submit the appointment request
5. Confirmation will be displayed

#### 4. **Viewing Medical History**
1. Access **Dashboard** → **Medical History**
2. View interactive charts of prescription trends
3. Review detailed prescription records
4. Track health metrics over time

### For Healthcare Providers

#### 1. **Creating Prescriptions**
1. Login with healthcare provider credentials
2. Navigate to **Create Prescription**
3. Enter patient information:
   - Patient name and age
   - Symptoms and diagnosis
   - Prescribed medications
4. Submit prescription (automatically dated)

## 🛠️ Troubleshooting

### Common Issues & Solutions

#### Database Connection Issues
**Problem**: `Cannot connect to database`
**Solutions**:
1. Verify MySQL is running: `systemctl status mysql` (Linux)
2. Check database credentials in environment variables
3. Ensure database exists: `SHOW DATABASES;`
4. Verify network connectivity to database server
5. Check MySQL error logs

#### Authentication Problems  
**Problem**: `Login failed` or `Session timeout`
**Solutions**:
1. Verify user exists in database: `SELECT * FROM users WHERE username='email';`
2. Check password hashing migration
3. Verify session configuration in `web.xml`
4. Clear browser cookies and cache
5. Check application logs for authentication errors

#### Application Won't Start
**Problem**: Tomcat deployment failures
**Solutions**:
1. Check Tomcat logs: `tail -f $TOMCAT_HOME/logs/catalina.out`
2. Verify Java version compatibility (JDK 8+)
3. Ensure all JAR dependencies are in `WEB-INF/lib/`
4. Check port availability (default: 8080)
5. Verify sufficient memory allocation

### Debug Mode
Enable detailed logging by setting log level in `web.xml`:
```xml
<context-param>
    <param-name>logLevel</param-name>
    <param-value>DEBUG</param-value>
</context-param>
```

## 🔐 Security Features

- **PBKDF2 Password Hashing** with 120,000 iterations
- **CSRF Protection** on all forms
- **SQL Injection Prevention** using PreparedStatements
- **XSS Protection** through input validation and sanitization
- **Session Security** with timeout and regeneration
- **Environment-based Credentials** (no hardcoded passwords)

## 📞 Support

For support and questions:
- **Issues**: Report bugs or request features
- **Documentation**: Check this README and inline code comments
- **Security Issues**: Please report privately

## 📝 License

This project is licensed under the MIT License. 

© 2025 Raghav's Prescription Management System. All rights reserved.