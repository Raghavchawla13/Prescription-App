-- Migration script to update existing database to new secure schema
-- Run this script on existing databases to apply security improvements

USE prescriptiondb;

-- Add salt column to users table if it doesn't exist
ALTER TABLE users 
    ADD COLUMN IF NOT EXISTS salt VARCHAR(255),
    ADD COLUMN IF NOT EXISTS created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    MODIFY username VARCHAR(100) UNIQUE NOT NULL,
    MODIFY password VARCHAR(255) NOT NULL,
    MODIFY name VARCHAR(100) NOT NULL;

-- Add index on username if it doesn't exist
ALTER TABLE users ADD INDEX IF NOT EXISTS idx_username (username);

-- Update appointments table
ALTER TABLE appointments 
    ADD COLUMN IF NOT EXISTS created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    MODIFY patient_name VARCHAR(100) NOT NULL,
    MODIFY date DATE NOT NULL;

-- Add indexes to appointments
ALTER TABLE appointments 
    ADD INDEX IF NOT EXISTS idx_date (date),
    ADD INDEX IF NOT EXISTS idx_patient_name (patient_name);

-- Update prescription table
ALTER TABLE prescription 
    ADD COLUMN IF NOT EXISTS created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    MODIFY patient_name VARCHAR(100) NOT NULL,
    MODIFY prescription_date DATE NOT NULL;

-- Add constraint for age (MySQL 8.0.16+)
-- Note: If using older MySQL version, this constraint may not work
ALTER TABLE prescription 
    ADD CONSTRAINT chk_age CHECK (age >= 0 AND age <= 150);

-- Add indexes to prescription
ALTER TABLE prescription 
    ADD INDEX IF NOT EXISTS idx_prescription_date (prescription_date),
    ADD INDEX IF NOT EXISTS idx_prescription_patient (patient_name);

-- Note: After running this migration, existing users will need to reset their passwords
-- to enable password hashing. The application will automatically migrate passwords
-- on first login with the old password.