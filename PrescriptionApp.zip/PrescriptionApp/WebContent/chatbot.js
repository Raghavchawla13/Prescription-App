document.addEventListener("DOMContentLoaded", () => {
    const chatHistory = document.getElementById("chat-history");
    const chatForm = document.getElementById("chat-form");
    const chatInput = document.getElementById("chat-input");

    chatForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const userInput = chatInput.value;
        chatInput.value = "";

        appendMessage("You", userInput);

        const response = await fetch("ChatbotServlet", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
            },
            body: `message=${encodeURIComponent(userInput)}`,
        });

        const botResponse = await response.text();
        appendMessage("Bot", botResponse);
    });

    function appendMessage(sender, message) {
        const messageElement = document.createElement("p");
        messageElement.innerHTML = `<strong>${sender}:</strong> ${message}`;
        chatHistory.appendChild(messageElement);
        chatHistory.scrollTop = chatHistory.scrollHeight;
    }
});