/**
 * Enhanced Error Management and User Feedback System
 * Provides toast notifications, form validation, and improved UX
 */

class ErrorManager {
    constructor() {
        this.toastContainer = this.createToastContainer();
        this.initializeFormValidation();
    }

    createToastContainer() {
        let container = document.getElementById('toast-container');
        if (!container) {
            container = document.createElement('div');
            container.id = 'toast-container';
            container.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                z-index: 1000;
                pointer-events: none;
            `;
            document.body.appendChild(container);
        }
        return container;
    }

    showToast(message, type = 'info', duration = 5000) {
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.style.cssText = `
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
            padding: 16px 20px;
            margin-bottom: 10px;
            max-width: 350px;
            pointer-events: all;
            transform: translateX(400px);
            transition: transform 0.3s ease;
            position: relative;
            border-left: 4px solid ${this.getTypeColor(type)};
        `;

        const icon = this.getTypeIcon(type);
        toast.innerHTML = `
            <div style="display: flex; align-items: center; gap: 12px;">
                <span style="font-size: 18px;">${icon}</span>
                <div style="flex: 1;">
                    <div style="font-weight: 600; color: #1f2937; margin-bottom: 4px;">
                        ${this.getTypeTitle(type)}
                    </div>
                    <div style="color: #6b7280; font-size: 14px;">
                        ${message}
                    </div>
                </div>
                <button onclick="this.parentElement.parentElement.remove()" 
                        style="background: none; border: none; font-size: 16px; cursor: pointer; color: #9ca3af; padding: 0; width: 20px; height: 20px;">
                    ×
                </button>
            </div>
        `;

        this.toastContainer.appendChild(toast);

        // Animate in
        setTimeout(() => {
            toast.style.transform = 'translateX(0)';
        }, 100);

        // Auto remove
        setTimeout(() => {
            if (toast.parentElement) {
                toast.style.transform = 'translateX(400px)';
                setTimeout(() => toast.remove(), 300);
            }
        }, duration);

        return toast;
    }

    getTypeColor(type) {
        const colors = {
            success: '#28a745',
            error: '#dc3545',
            warning: '#ffc107',
            info: '#17a2b8'
        };
        return colors[type] || colors.info;
    }

    getTypeIcon(type) {
        const icons = {
            success: '✓',
            error: '⚠',
            warning: '⚡',
            info: 'ℹ'
        };
        return icons[type] || icons.info;
    }

    getTypeTitle(type) {
        const titles = {
            success: 'Success',
            error: 'Error',
            warning: 'Warning',
            info: 'Information'
        };
        return titles[type] || titles.info;
    }

    // Form validation enhancement
    initializeFormValidation() {
        document.addEventListener('DOMContentLoaded', () => {
            this.enhanceForms();
        });
    }

    enhanceForms() {
        const forms = document.querySelectorAll('form');
        forms.forEach(form => {
            this.addFormValidation(form);
            this.addLoadingStates(form);
        });
    }

    addFormValidation(form) {
        const inputs = form.querySelectorAll('input, textarea, select');
        
        inputs.forEach(input => {
            // Real-time validation
            input.addEventListener('blur', () => this.validateField(input));
            input.addEventListener('input', () => this.clearFieldError(input));
            
            // Add visual feedback elements
            this.addFieldFeedback(input);
        });

        // Form submission enhancement
        form.addEventListener('submit', (e) => {
            if (!this.validateForm(form)) {
                e.preventDefault();
                this.showToast('Please fix the errors in the form', 'error');
            } else {
                this.showFormLoading(form);
            }
        });
    }

    addFieldFeedback(input) {
        const formGroup = input.closest('.form-group') || input.parentElement;
        
        if (!formGroup.querySelector('.form-feedback')) {
            const feedback = document.createElement('div');
            feedback.className = 'form-feedback';
            formGroup.appendChild(feedback);
        }
    }

    validateField(input) {
        const formGroup = input.closest('.form-group') || input.parentElement;
        const feedback = formGroup.querySelector('.form-feedback');
        let isValid = true;
        let message = '';

        // Remove previous validation classes
        formGroup.classList.remove('has-error', 'has-success');

        // Required field validation
        if (input.hasAttribute('required') && !input.value.trim()) {
            isValid = false;
            message = 'This field is required';
        }

        // Email validation
        if (input.type === 'email' && input.value.trim()) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(input.value)) {
                isValid = false;
                message = 'Please enter a valid email address';
            }
        }

        // Password validation
        if (input.type === 'password' && input.value.trim()) {
            if (input.value.length < 8) {
                isValid = false;
                message = 'Password must be at least 8 characters long';
            } else if (!/(?=.*[a-zA-Z])(?=.*[0-9])/.test(input.value)) {
                isValid = false;
                message = 'Password must contain both letters and numbers';
            }
        }

        // Age validation
        if (input.name === 'age' && input.value.trim()) {
            const age = parseInt(input.value);
            if (isNaN(age) || age < 0 || age > 150) {
                isValid = false;
                message = 'Please enter a valid age (0-150)';
            }
        }

        // Update UI
        if (isValid && input.value.trim()) {
            formGroup.classList.add('has-success');
            feedback.textContent = '';
            feedback.className = 'form-feedback success';
        } else if (!isValid) {
            formGroup.classList.add('has-error');
            feedback.textContent = message;
            feedback.className = 'form-feedback error';
        }

        return isValid;
    }

    clearFieldError(input) {
        const formGroup = input.closest('.form-group') || input.parentElement;
        const feedback = formGroup.querySelector('.form-feedback');
        
        if (formGroup.classList.contains('has-error')) {
            formGroup.classList.remove('has-error');
            if (feedback) {
                feedback.textContent = '';
            }
        }
    }

    validateForm(form) {
        const inputs = form.querySelectorAll('input[required], textarea[required], select[required]');
        let isValid = true;

        inputs.forEach(input => {
            if (!this.validateField(input)) {
                isValid = false;
            }
        });

        return isValid;
    }

    addLoadingStates(form) {
        const submitButton = form.querySelector('button[type="submit"], input[type="submit"]');
        if (!submitButton) return;

        // Store original text
        const originalText = submitButton.textContent || submitButton.value;

        form.addEventListener('submit', () => {
            if (this.validateForm(form)) {
                this.showFormLoading(form);
            }
        });
    }

    showFormLoading(form) {
        const submitButton = form.querySelector('button[type="submit"], input[type="submit"]');
        if (!submitButton) return;

        const originalText = submitButton.textContent || submitButton.value;
        submitButton.disabled = true;
        
        if (submitButton.tagName === 'BUTTON') {
            submitButton.innerHTML = `
                <span class="loading-spinner"></span>
                Processing...
            `;
        } else {
            submitButton.value = 'Processing...';
        }

        // Reset after 10 seconds as fallback
        setTimeout(() => {
            submitButton.disabled = false;
            if (submitButton.tagName === 'BUTTON') {
                submitButton.textContent = originalText;
            } else {
                submitButton.value = originalText;
            }
        }, 10000);
    }

    // Enhanced error display for server responses
    displayServerError(message, details = null) {
        this.showToast(message, 'error', 7000);
        
        if (details && console) {
            console.error('Server Error Details:', details);
        }
    }

    displaySuccessMessage(message) {
        this.showToast(message, 'success', 4000);
    }

    // Utility methods for common scenarios
    showNetworkError() {
        this.showToast('Network error. Please check your connection and try again.', 'error');
    }

    showValidationError(fieldErrors) {
        if (typeof fieldErrors === 'string') {
            this.showToast(fieldErrors, 'error');
        } else if (Array.isArray(fieldErrors)) {
            fieldErrors.forEach(error => this.showToast(error, 'error'));
        }
    }

    // Initialize global error handlers
    initializeGlobalHandlers() {
        // Handle unhandled promise rejections
        window.addEventListener('unhandledrejection', (event) => {
            console.error('Unhandled promise rejection:', event.reason);
            this.showToast('An unexpected error occurred. Please try again.', 'error');
        });

        // Handle JavaScript errors
        window.addEventListener('error', (event) => {
            console.error('JavaScript error:', event.error);
            this.showToast('An error occurred while loading the page.', 'error');
        });
    }
}

// Initialize error manager
const errorManager = new ErrorManager();
errorManager.initializeGlobalHandlers();

// Make it globally available
window.errorManager = errorManager;

// Backward compatibility functions
function showToast(message, type, duration) {
    return errorManager.showToast(message, type, duration);
}

function showError(message) {
    return errorManager.displayServerError(message);
}

function showSuccess(message) {
    return errorManager.displaySuccessMessage(message);
}