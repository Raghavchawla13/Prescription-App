document.addEventListener("DOMContentLoaded", function () {
    const canvas = document.getElementById('historyChart');
    if (!canvas) { return; }
    
    // Check if chart data is available from the page
    if (typeof window.chartLabels === 'undefined' || typeof window.chartData === 'undefined') {
        console.warn('Chart data not available. Chart will not be rendered.');
        return;
    }
    
    const ctx = canvas.getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: window.chartLabels || [],
            datasets: [{
                label: 'Prescriptions Over Time',
                data: window.chartData || [],
                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: { precision: 0 }
                }
            },
            responsive: true,
            maintainAspectRatio: false
        }
    });
});
