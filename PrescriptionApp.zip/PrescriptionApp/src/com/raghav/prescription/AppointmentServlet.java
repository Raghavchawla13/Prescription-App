package com.raghav.prescription;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Date;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AppointmentServlet extends HttpServlet {
    private static final Logger logger = Logger.getLogger(AppointmentServlet.class.getName());
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String patientName = request.getParameter("patientName");
        String appointmentDate = request.getParameter("appointmentDate");
        String reason = request.getParameter("reason");
        
        // Input validation
        if (patientName == null || patientName.trim().isEmpty() ||
            appointmentDate == null || appointmentDate.trim().isEmpty()) {
            request.setAttribute("confirmation", "Please provide both your full name and a preferred date.");
            request.getRequestDispatcher("/appointment.jsp").forward(request, response);
            return;
        }
        
        // Validate input formats
        if (!ValidationUtil.isValidName(patientName)) {
            request.setAttribute("confirmation", "Invalid name format. Please use only letters, spaces, and hyphens.");
            request.getRequestDispatcher("/appointment.jsp").forward(request, response);
            return;
        }
        
        if (!ValidationUtil.isValidDate(appointmentDate)) {
            request.setAttribute("confirmation", "Invalid date format. Please use YYYY-MM-DD format.");
            request.getRequestDispatcher("/appointment.jsp").forward(request, response);
            return;
        }
        
        if (reason != null && !reason.trim().isEmpty() && !ValidationUtil.isValidText(reason)) {
            request.setAttribute("confirmation", "Invalid reason text. Please avoid special characters.");
            request.getRequestDispatcher("/appointment.jsp").forward(request, response);
            return;
        }
        
        // Sanitize inputs
        patientName = ValidationUtil.sanitizeHtml(patientName.trim());
        reason = reason != null ? ValidationUtil.sanitizeHtml(reason.trim()) : "";
        
        logger.info("Received appointment request for patient on " + appointmentDate);
        
        Connection con = null;
        PreparedStatement ps = null;
        try {
            con = DBConnection.getConnection();
            if (con == null) {
                logger.severe("Database connection failed");
                request.setAttribute("confirmation", "Unable to connect to database. Ensure MySQL is running and the schema (SQL/schema.sql) is installed. If needed, set DB_URL, DB_USER, DB_PASSWORD.");
                request.getRequestDispatcher("/appointment.jsp").forward(request, response);
                return;
            }

            java.sql.Date sqlDate;
            try {
                sqlDate = Date.valueOf(appointmentDate);
            } catch (IllegalArgumentException iae) {
                request.setAttribute("confirmation", "Invalid date. Please select a valid date.");
                request.getRequestDispatcher("/appointment.jsp").forward(request, response);
                return;
            }

            ps = con.prepareStatement("INSERT INTO appointments (patient_name, date, reason) VALUES (?, ?, ?)");
            ps.setString(1, patientName);
            ps.setDate(2, sqlDate);
            ps.setString(3, reason);

            int result = ps.executeUpdate();

            if (result > 0) {
                String confirmation = "Your appointment has been successfully booked for " + appointmentDate + ".";
                request.setAttribute("confirmation", confirmation);
                logger.info("Appointment booked successfully for date: " + appointmentDate);
            } else {
                request.setAttribute("confirmation", "Failed to book appointment. Please try again.");
                logger.warning("Failed to insert appointment record");
            }
        } catch (Exception e) {
            logger.severe("Error saving appointment: " + e.getMessage());
            request.setAttribute("confirmation", "An error occurred while booking your appointment: " + e.getMessage());
        } finally {
            // Proper resource cleanup
            if (ps != null) {
                try { ps.close(); } catch (Exception ignore) { }
            }
            if (con != null) {
                try { con.close(); } catch (Exception ignore) { }
            }
        }

        RequestDispatcher rd = request.getRequestDispatcher("/appointment.jsp");
        rd.forward(request, response);
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // If someone navigates to /appointment directly, show the appointment page
        RequestDispatcher rd = request.getRequestDispatcher("/appointment.jsp");
        rd.forward(request, response);
    }
}