package com.raghav.prescription;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.logging.Logger;

public class AuthenticationFilter implements Filter {
    private static final Logger LOGGER = Logger.getLogger(AuthenticationFilter.class.getName());
    
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Initialization code if needed
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;
        
        String requestURI = httpRequest.getRequestURI();
        LOGGER.info("Filtering request: " + requestURI);
        
        // Get the session, don't create if it doesn't exist
        HttpSession session = httpRequest.getSession(false);
        
        // Check if the user is logged in using single authentication attribute
        // Only userId is used as the authentication marker
        boolean isLoggedIn = (session != null && session.getAttribute("userId") != null);
        boolean isLoginPage = requestURI.endsWith("/login.jsp") || requestURI.endsWith("/login");
        boolean isRegisterPage = requestURI.endsWith("/register.jsp") || requestURI.endsWith("/register");
        boolean isIndexPage = requestURI.endsWith("/index.jsp") || requestURI.equals(httpRequest.getContextPath() + "/");
        boolean isResourceRequest = requestURI.endsWith(".css") || requestURI.endsWith(".js") || 
                                   requestURI.endsWith(".png") || requestURI.endsWith(".jpg") ||
                                   requestURI.endsWith(".gif") || requestURI.endsWith(".svg") ||
                                   requestURI.endsWith(".ico") || requestURI.endsWith(".woff") ||
                                   requestURI.endsWith(".woff2") || requestURI.endsWith(".ttf") ||
                                   requestURI.endsWith(".eot") || requestURI.endsWith(".map");
        boolean isLanguageRequest = requestURI.endsWith("/LanguageServlet");
        boolean isChatbotRequest = requestURI.endsWith("/ChatbotServlet");
        boolean isSymptomRequest = requestURI.endsWith("/SymptomCheckerServlet");
        
        if (isLoggedIn || isLoginPage || isRegisterPage || isIndexPage || isResourceRequest || isLanguageRequest || isChatbotRequest || isSymptomRequest) {
            // User is logged in or accessing public pages/resources, proceed
            chain.doFilter(request, response);
        } else {
            // User is not logged in and trying to access protected page, redirect to login
            LOGGER.info("Unauthorized access attempt to " + requestURI + ". Redirecting to login page.");
            httpResponse.sendRedirect(httpRequest.getContextPath() + "/login.jsp");
        }
    }

    @Override
    public void destroy() {
        // Cleanup code if needed
    }
}