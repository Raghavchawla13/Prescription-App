package com.raghav.prescription;

import java.security.SecureRandom;
import java.util.Base64;
import javax.servlet.http.HttpSession;
import java.util.logging.Logger;

public class CSRFUtil {
    private static final Logger LOGGER = Logger.getLogger(CSRFUtil.class.getName());
    private static final String CSRF_TOKEN_SESSION_ATTR = "csrfToken";
    private static final int TOKEN_LENGTH = 32;
    private static final SecureRandom secureRandom = new SecureRandom();
    
    /**
     * Generates a new CSRF token and stores it in the session
     */
    public static String generateToken(HttpSession session) {
        if (session == null) {
            throw new IllegalArgumentException("Session cannot be null");
        }
        
        byte[] tokenBytes = new byte[TOKEN_LENGTH];
        secureRandom.nextBytes(tokenBytes);
        String token = Base64.getUrlEncoder().withoutPadding().encodeToString(tokenBytes);
        
        session.setAttribute(CSRF_TOKEN_SESSION_ATTR, token);
        LOGGER.fine("Generated new CSRF token for session: " + session.getId());
        
        return token;
    }
    
    /**
     * Gets the current CSRF token from the session, generating one if it doesn't exist
     */
    public static String getToken(HttpSession session) {
        if (session == null) {
            return null;
        }
        
        String token = (String) session.getAttribute(CSRF_TOKEN_SESSION_ATTR);
        if (token == null) {
            token = generateToken(session);
        }
        
        return token;
    }
    
    /**
     * Validates the provided CSRF token against the one stored in the session
     */
    public static boolean validateToken(HttpSession session, String providedToken) {
        if (session == null || providedToken == null || providedToken.trim().isEmpty()) {
            LOGGER.warning("CSRF validation failed: null session or token");
            return false;
        }
        
        String sessionToken = (String) session.getAttribute(CSRF_TOKEN_SESSION_ATTR);
        if (sessionToken == null) {
            LOGGER.warning("CSRF validation failed: no token in session");
            return false;
        }
        
        // Use constant-time comparison to prevent timing attacks
        boolean valid = constantTimeEquals(sessionToken, providedToken.trim());
        
        if (!valid) {
            LOGGER.warning("CSRF validation failed: token mismatch");
        }
        
        return valid;
    }
    
    /**
     * Constant-time string comparison to prevent timing attacks
     */
    private static boolean constantTimeEquals(String a, String b) {
        if (a == null || b == null) {
            return false;
        }
        
        if (a.length() != b.length()) {
            return false;
        }
        
        int result = 0;
        for (int i = 0; i < a.length(); i++) {
            result |= a.charAt(i) ^ b.charAt(i);
        }
        
        return result == 0;
    }
    
    /**
     * Clears the CSRF token from the session
     */
    public static void clearToken(HttpSession session) {
        if (session != null) {
            session.removeAttribute(CSRF_TOKEN_SESSION_ATTR);
        }
    }
}