package com.raghav.prescription;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ChatbotServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/plain;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        String raw = request.getParameter("message");
        
        // Validate message input
        if (raw != null && !ValidationUtil.isValidLength(raw, 500)) {
            response.getWriter().write("Message is too long. Please keep it under 500 characters.");
            return;
        }
        
        // Sanitize input to prevent XSS
        String message = raw == null ? "" : ValidationUtil.sanitizeHtml(raw.toLowerCase());
        String botResponse;

        if (message.contains("hello") || message.contains("hi")) {
            botResponse = "Hello! How can I help you today?";
        } else if (message.contains("appointment")) {
            botResponse = "You can book an appointment through the dashboard.";
        } else if (message.contains("symptoms")) {
            botResponse = "You can check your symptoms using our AI Symptom Checker, also available on the dashboard.";
        } else {
            botResponse = "I'm sorry, I don't understand. I am still under development.";
        }

        response.getWriter().write(botResponse);
    }
}