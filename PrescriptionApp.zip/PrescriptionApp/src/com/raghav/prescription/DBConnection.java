package com.raghav.prescription;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DBConnection {
    private static final Logger LOGGER = Logger.getLogger(DBConnection.class.getName());

    // Configuration via environment variables or system properties only - no hardcoded credentials
    private static final String DEFAULT_URL = "jdbc:mysql://localhost:3306/prescriptiondb?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String DEFAULT_USER = "root";
    // SECURITY: Password must be provided via environment variable DB_PASSWORD or system property db.password
    private static final String DEFAULT_PASSWORD = null;

    private static String resolve(String envKey, String sysPropKey, String defaultValue) {
        String fromEnv = System.getenv(envKey);
        if (fromEnv != null && !fromEnv.trim().isEmpty()) {
            return fromEnv.trim();
        }
        String fromProp = System.getProperty(sysPropKey);
        if (fromProp != null && !fromProp.trim().isEmpty()) {
            return fromProp.trim();
        }
        return defaultValue;
    }

    public static Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            String url = resolve("DB_URL", "db.url", DEFAULT_URL);
            String user = resolve("DB_USER", "db.user", DEFAULT_USER);
            String password = resolve("DB_PASSWORD", "db.password", DEFAULT_PASSWORD);
            
            // Security check: Ensure password is provided
            if (password == null || password.trim().isEmpty()) {
                LOGGER.log(Level.SEVERE, "Database password not configured. Set DB_PASSWORD environment variable or db.password system property.");
                throw new IllegalStateException("Database password must be configured via environment variable or system property");
            }

            Connection connection = DriverManager.getConnection(url, user, password);
            return connection;
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Failed to obtain DB connection", e);
            return null; // Preserve existing behavior expected by callers
        }
    }
}