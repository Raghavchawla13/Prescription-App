package com.raghav.prescription;

import java.io.IOException;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class HistoryServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<String> dates = new ArrayList<>();
        List<Integer> countList = new ArrayList<>();

        Connection con = DBConnection.getConnection();
        try {
            if (con == null) {
                request.setAttribute("labels", dates);
                request.setAttribute("data", countList);
                request.setAttribute("info", "Cannot connect to database. Start MySQL and install the schema (SQL/schema.sql). Configure DB_URL, DB_USER, DB_PASSWORD if needed.");
                request.getRequestDispatcher("/history.jsp").forward(request, response);
                return;
            }
            // Use PreparedStatement for consistency and best practices
            String query = "SELECT prescription_date, COUNT(*) as count FROM prescription GROUP BY prescription_date ORDER BY prescription_date";
            try (PreparedStatement pst = con.prepareStatement(query)) {
                try (ResultSet rs = pst.executeQuery()) {
                    while (rs.next()) {
                        java.sql.Date date = rs.getDate("prescription_date");
                        int count = rs.getInt("count");

                        // Convert date to String in yyyy-MM-dd format
                        dates.add(date.toString());
                        countList.add(count);
                    }
                }
            }

            request.setAttribute("labels", dates);
            request.setAttribute("data", countList);

            RequestDispatcher rd = request.getRequestDispatcher("/history.jsp");
            rd.forward(request, response);

        } catch (Exception e) {
            // provide guidance for troubleshooting
            request.setAttribute("labels", dates);
            request.setAttribute("data", countList);
            request.setAttribute("info", "Error loading data. Ensure database is running and the schema is installed.");
            request.getRequestDispatcher("/history.jsp").forward(request, response);
        } finally {
            if (con != null) {
                try { con.close(); } catch (SQLException ignore) { }
            }
        }
    }
}
