package com.raghav.prescription;

import java.io.IOException;
import java.util.Locale;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LanguageServlet extends HttpServlet {
    private static final Logger LOGGER = Logger.getLogger(LanguageServlet.class.getName());
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String language = request.getParameter("lang");
        String redirect = request.getParameter("redirect");
        
        LOGGER.info("Language change request to: " + language);
        
        if (language == null || language.isEmpty()) {
            language = "en"; // Default to English
        }
        
        // Only accept valid languages
        if (!language.equals("en") && !language.equals("hi")) {
            language = "en";
        }
        
        Locale locale = new Locale(language);
        HttpSession session = request.getSession();
        session.setAttribute("javax.servlet.jsp.jstl.fmt.locale", language);
        session.setAttribute("javax.servlet.jsp.jstl.fmt.locale.session", language);
        session.setAttribute("language", language);
        
        LOGGER.info("Language changed to: " + language);
        
        // Secure redirect - prevent open redirect vulnerability
        String contextPath = request.getContextPath();
        String fallback = contextPath + "/index.jsp";
        String redirectUrl = fallback;
        
        if (redirect != null && !redirect.isEmpty()) {
            // Validate redirect parameter - must be a relative path within the application
            if (isValidRedirectPath(redirect, contextPath)) {
                if (redirect.startsWith("/")) {
                    redirectUrl = contextPath + redirect;
                } else {
                    redirectUrl = contextPath + "/" + redirect;
                }
            } else {
                LOGGER.warning("Invalid redirect attempt blocked: " + redirect);
            }
        } else {
            // Use referer only if it's from the same application
            String referer = request.getHeader("Referer");
            if (referer != null && !referer.isEmpty()) {
                String serverUrl = request.getScheme() + "://" + request.getServerName() + 
                                  ":" + request.getServerPort() + contextPath;
                if (referer.startsWith(serverUrl)) {
                    redirectUrl = referer;
                }
            }
        }

        LOGGER.info("Redirecting to: " + redirectUrl);
        response.sendRedirect(redirectUrl);
    }
    
    /**
     * Validates that the redirect path is safe and within the application
     */
    private boolean isValidRedirectPath(String path, String contextPath) {
        if (path == null || path.isEmpty()) {
            return false;
        }
        
        // Block absolute URLs
        if (path.contains("://") || path.startsWith("//")) {
            return false;
        }
        
        // Block path traversal attempts
        if (path.contains("..") || path.contains("\\")) {
            return false;
        }
        
        // Allow only application paths
        if (path.startsWith("/")) {
            // Must be a path within our application
            return path.endsWith(".jsp") || path.endsWith(".html") || 
                   path.equals("/dashboard") || path.equals("/appointment") ||
                   path.equals("/prescription") || path.equals("/history") ||
                   path.equals("/symptom") || path.equals("/");
        }
        
        // Relative paths within the app
        return path.endsWith(".jsp") || path.endsWith(".html");
    }
}
