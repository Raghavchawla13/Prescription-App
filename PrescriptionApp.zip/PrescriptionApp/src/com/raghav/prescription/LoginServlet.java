package com.raghav.prescription;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.logging.Logger;
import java.util.logging.Level;

public class LoginServlet extends HttpServlet {
    private static final Logger LOGGER = Logger.getLogger(LoginServlet.class.getName());
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        LOGGER.info("Login attempt for username: " + username);

        if (username == null || password == null || username.trim().isEmpty() || password.trim().isEmpty()) {
            request.setAttribute("error", "Username and password are required.");
            RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
            rd.forward(request, response);
            return;
        }
        
        // Validate email format for username
        if (!ValidationUtil.isValidEmail(username)) {
            request.setAttribute("error", "Please provide a valid email address.");
            RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
            rd.forward(request, response);
            return;
        }
        
        // CSRF Protection
        String csrfToken = request.getParameter("csrfToken");
        if (!CSRFUtil.validateToken(request.getSession(), csrfToken)) {
            request.setAttribute("error", "Invalid request. Please try again.");
            RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
            rd.forward(request, response);
            return;
        }

        try {
            Connection con = DBConnection.getConnection();
            
            if (con == null) {
                LOGGER.severe("Database connection failed");
                request.setAttribute("error", "Cannot connect to database. Please ensure MySQL is running and the schema is installed (run SQL/schema.sql). You can also set DB_URL, DB_USER, DB_PASSWORD environment variables if needed.");
                RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
                rd.forward(request, response);
                return;
            }
            
            // Fetch user with salt for password verification
            PreparedStatement pst = con.prepareStatement("SELECT * FROM users WHERE username=?");
            pst.setString(1, username);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                String storedHash = rs.getString("password");
                String storedSalt = rs.getString("salt");
                
                // Check if this is a legacy unhashed password (for migration)
                if (storedSalt == null || storedSalt.isEmpty()) {
                    // Legacy plain text password - should be migrated
                    if (password.equals(storedHash)) {
                        // Migrate to hashed password
                        String newSalt = PasswordUtil.generateSalt();
                        String newHash = PasswordUtil.hashPassword(password, newSalt);
                        PreparedStatement updatePst = con.prepareStatement("UPDATE users SET password=?, salt=? WHERE id=?");
                        updatePst.setString(1, newHash);
                        updatePst.setString(2, newSalt);
                        updatePst.setInt(3, rs.getInt("id"));
                        updatePst.executeUpdate();
                        updatePst.close();
                        
                        // Login success after migration
                        // Prevent session fixation attacks by regenerating session ID
                        HttpSession oldSession = request.getSession(false);
                        if (oldSession != null) {
                            oldSession.invalidate();
                        }
                        HttpSession session = request.getSession(true);
                        session.setAttribute("userName", rs.getString("name"));
                        session.setAttribute("userId", rs.getInt("id"));
                        session.setAttribute("userUsername", rs.getString("username"));
                        LOGGER.info("Login successful (password migrated) for user: " + username);
                        response.sendRedirect(request.getContextPath() + "/dashboard.jsp?welcome=true");
                    } else {
                        // Login failed
                        LOGGER.info("Login failed for user: " + username);
                        request.setAttribute("error", "Login failed. Invalid username or password.");
                        RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
                        rd.forward(request, response);
                    }
                } else {
                    // Verify hashed password
                    if (PasswordUtil.verifyPassword(password, storedHash, storedSalt)) {
                        // Login success
                        // Prevent session fixation attacks by regenerating session ID
                        HttpSession oldSession = request.getSession(false);
                        if (oldSession != null) {
                            oldSession.invalidate();
                        }
                        HttpSession session = request.getSession(true);
                        session.setAttribute("userName", rs.getString("name"));
                        session.setAttribute("userId", rs.getInt("id"));
                        session.setAttribute("userUsername", rs.getString("username"));
                        LOGGER.info("Login successful for user: " + username);
                        response.sendRedirect(request.getContextPath() + "/dashboard.jsp?welcome=true");
                    } else {
                        // Login failed
                        LOGGER.info("Login failed for user: " + username);
                        request.setAttribute("error", "Login failed. Invalid username or password.");
                        RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
                        rd.forward(request, response);
                    }
                }
            } else {
                // User not found
                LOGGER.info("Login failed - user not found: " + username);
                request.setAttribute("error", "Login failed. Invalid username or password.");
                RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
                rd.forward(request, response);
            }
            
            // Close resources
            rs.close();
            pst.close();
            con.close();

        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "SQL error during login", e);
            request.setAttribute("error", "Database error occurred. Please try again later.");
            RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Unexpected error during login", e);
            request.setAttribute("error", "An unexpected error occurred. Please try again.");
            RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
            rd.forward(request, response);
        }
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // If someone navigates to /login directly, show the login page
        RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
        rd.forward(request, response);
    }
}
