package com.raghav.prescription;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class PrescriptionServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String name = request.getParameter("patient_name");
        String ageParam = request.getParameter("age");
        String symptoms = request.getParameter("symptoms");
        String diagnosis = request.getParameter("diagnosis");
        String medicines = request.getParameter("medicines");
        
        // Validate patient name
        if (!ValidationUtil.isValidName(name)) {
            request.setAttribute("message", "Please provide a valid patient name (letters, spaces, hyphens, apostrophes only).");
            request.getRequestDispatcher("/prescription.jsp").forward(request, response);
            return;
        }
        
        // Validate age
        if (!ValidationUtil.isValidAge(ageParam)) {
            request.setAttribute("message", "Please provide a valid age (0-150).");
            request.getRequestDispatcher("/prescription.jsp").forward(request, response);
            return;
        }
        
        int age = Integer.parseInt(ageParam.trim());
        
        // Validate and sanitize other fields
        if (!ValidationUtil.isValidLength(symptoms, 500) || !ValidationUtil.isValidLength(diagnosis, 500) || !ValidationUtil.isValidLength(medicines, 500)) {
            request.setAttribute("message", "Text fields cannot exceed 500 characters.");
            request.getRequestDispatcher("/prescription.jsp").forward(request, response);
            return;
        }
        
        // Sanitize text inputs to prevent XSS
        symptoms = ValidationUtil.sanitizeHtml(symptoms);
        diagnosis = ValidationUtil.sanitizeHtml(diagnosis);
        medicines = ValidationUtil.sanitizeHtml(medicines);

        Connection con = DBConnection.getConnection();
        try {
            if (con == null) {
                request.setAttribute("message", "Cannot connect to database. Start MySQL and install the schema (SQL/schema.sql). Configure DB_URL, DB_USER, DB_PASSWORD if needed.");
                request.getRequestDispatcher("/prescription.jsp").forward(request, response);
                return;
            }
            try (PreparedStatement ps = con.prepareStatement(
                "INSERT INTO prescription (patient_name, age, symptoms, diagnosis, medicines, prescription_date) VALUES (?, ?, ?, ?, ?, ?)"
            )) {
                ps.setString(1, name);
                ps.setInt(2, age);
                ps.setString(3, symptoms);
                ps.setString(4, diagnosis);
                ps.setString(5, medicines);

                // Set current date manually
                java.sql.Date currentDate = new java.sql.Date(System.currentTimeMillis());
                ps.setDate(6, currentDate);

                int result = ps.executeUpdate();

                if (result > 0) {
                    request.setAttribute("message", "Prescription saved successfully.");
                } else {
                    request.setAttribute("message", "Failed to save prescription.");
                }
            }

            RequestDispatcher rd = request.getRequestDispatcher("/prescription.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            request.setAttribute("message", "An error occurred.");
            request.getRequestDispatcher("/prescription.jsp").forward(request, response);
        } finally {
            if (con != null) {
                try { con.close(); } catch (SQLException ignore) { }
            }
        }
    }
}
