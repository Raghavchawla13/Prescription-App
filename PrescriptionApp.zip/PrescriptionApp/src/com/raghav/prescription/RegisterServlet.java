package com.raghav.prescription;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.logging.Logger;
import java.util.logging.Level;

public class RegisterServlet extends HttpServlet {
    private static final Logger LOGGER = Logger.getLogger(RegisterServlet.class.getName());
    
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        
        LOGGER.info("Registration attempt for email: " + email);

        // Validate input
        if (name == null || email == null || password == null || 
            name.trim().isEmpty() || email.trim().isEmpty() || password.trim().isEmpty()) {
            request.setAttribute("error", "All fields are required. Provide full name, a valid email, and a password.");
            RequestDispatcher rd = request.getRequestDispatcher("/register.jsp");
            rd.forward(request, response);
            return;
        }
        
        // Validate name format
        if (!ValidationUtil.isValidName(name)) {
            request.setAttribute("error", "Name must contain only letters, spaces, hyphens, and apostrophes (2-100 characters).");
            RequestDispatcher rd = request.getRequestDispatcher("/register.jsp");
            rd.forward(request, response);
            return;
        }
        
        // Validate email format
        if (!ValidationUtil.isValidEmail(email)) {
            request.setAttribute("error", "Please provide a valid email address.");
            RequestDispatcher rd = request.getRequestDispatcher("/register.jsp");
            rd.forward(request, response);
            return;
        }
        
        // Validate password strength
        if (!ValidationUtil.isValidPassword(password)) {
            request.setAttribute("error", "Password must be at least 8 characters and contain both letters and numbers.");
            RequestDispatcher rd = request.getRequestDispatcher("/register.jsp");
            rd.forward(request, response);
            return;
        }
        
        // Sanitize name to prevent XSS
        name = ValidationUtil.sanitizeHtml(name);
        
        // CSRF Protection
        String csrfToken = request.getParameter("csrfToken");
        if (!CSRFUtil.validateToken(request.getSession(), csrfToken)) {
            request.setAttribute("error", "Invalid request. Please try again.");
            RequestDispatcher rd = request.getRequestDispatcher("/register.jsp");
            rd.forward(request, response);
            return;
        }

        try {
            Connection con = DBConnection.getConnection();
            
            if (con == null) {
                LOGGER.severe("Database connection failed");
                request.setAttribute("error", "Cannot connect to database. Please start MySQL and run SQL/schema.sql to create the schema. Configure DB_URL, DB_USER, DB_PASSWORD if your setup differs.");
                RequestDispatcher rd = request.getRequestDispatcher("/register.jsp");
                rd.forward(request, response);
                return;
            }
            
            // Check if email already exists
            PreparedStatement checkStmt = con.prepareStatement("SELECT * FROM users WHERE username = ?");
            checkStmt.setString(1, email);
            ResultSet rs = checkStmt.executeQuery();
            
            if (rs.next()) {
                LOGGER.info("Registration failed - email already exists: " + email);
                request.setAttribute("error", "Email already registered. Please use a different email or login.");
                RequestDispatcher rd = request.getRequestDispatcher("/register.jsp");
                rd.forward(request, response);
                rs.close();
                checkStmt.close();
                con.close();
                return;
            }
            
            rs.close();
            checkStmt.close();
            
            // Hash password before storing
            String salt = PasswordUtil.generateSalt();
            String hashedPassword = PasswordUtil.hashPassword(password, salt);
            
            // Insert new user with hashed password and salt
            PreparedStatement pst = con.prepareStatement("INSERT INTO users (username, password, salt, name) VALUES (?, ?, ?, ?)");
            pst.setString(1, email);
            pst.setString(2, hashedPassword);
            pst.setString(3, salt);
            pst.setString(4, name);
            int rowsAffected = pst.executeUpdate();
            
            if (rowsAffected > 0) {
                LOGGER.info("Registration successful for: " + email);
                request.setAttribute("success", "Registration successful. Please login.");
                RequestDispatcher rd = request.getRequestDispatcher("/login.jsp");
                rd.forward(request, response);
            } else {
                LOGGER.warning("Registration failed - no rows affected for: " + email);
                request.setAttribute("error", "Registration failed. Please try again.");
                RequestDispatcher rd = request.getRequestDispatcher("/register.jsp");
                rd.forward(request, response);
            }
            
            pst.close();
            con.close();
            
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "SQL error during registration", e);
            request.setAttribute("error", "Database error occurred. Please try again later.");
            RequestDispatcher rd = request.getRequestDispatcher("/register.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Unexpected error during registration", e);
            request.setAttribute("error", "An unexpected error occurred. Please try again.");
            RequestDispatcher rd = request.getRequestDispatcher("/register.jsp");
            rd.forward(request, response);
        }
    }
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // If someone navigates to /register directly, show the registration page
        RequestDispatcher rd = request.getRequestDispatcher("/register.jsp");
        rd.forward(request, response);
    }
}
