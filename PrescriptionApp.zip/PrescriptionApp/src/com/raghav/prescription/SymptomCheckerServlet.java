package com.raghav.prescription;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SymptomCheckerServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String raw = request.getParameter("symptoms");
        if (raw == null || raw.trim().isEmpty()) {
            request.setAttribute("prediction", "No symptoms provided. Please enter a few words about how you feel.");
            request.getRequestDispatcher("/symptom.jsp").forward(request, response);
            return;
        }
        
        // Validate input length and content
        if (!ValidationUtil.isValidLength(raw, 500)) {
            request.setAttribute("prediction", "Symptom description is too long. Please keep it under 500 characters.");
            request.getRequestDispatcher("/symptom.jsp").forward(request, response);
            return;
        }
        
        // Sanitize input to prevent XSS
        String symptoms = ValidationUtil.sanitizeHtml(raw.toLowerCase());
        String prediction;

        if (symptoms.contains("fever") && symptoms.contains("headache")) {
            prediction = "Possible flu. It's recommended to rest and drink plenty of fluids. If symptoms persist, consult a doctor.";
        } else if (symptoms.contains("sore") && symptoms.contains("throat")) {
            prediction = "Possible viral infection. Gargle with salt water and avoid cold beverages.";
        } else if (symptoms.contains("rash") && symptoms.contains("fatigue")) {
            prediction = "Could be dengue. Please see a doctor immediately for a blood test.";
        } else {
            prediction = "Your symptoms are unclear. For a more accurate diagnosis, please consult a healthcare professional.";
        }

        request.setAttribute("prediction", prediction);
        RequestDispatcher rd = request.getRequestDispatcher("/symptom.jsp");
        rd.forward(request, response);
    }
}
