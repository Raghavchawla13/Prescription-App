package com.raghav.prescription;

import java.util.regex.Pattern;
import java.util.logging.Logger;

public class ValidationUtil {
    private static final Logger LOGGER = Logger.getLogger(ValidationUtil.class.getName());
    
    // Regex patterns for validation
    private static final Pattern EMAIL_PATTERN = Pattern.compile(
        "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$"
    );
    
    private static final Pattern NAME_PATTERN = Pattern.compile(
        "^[A-Za-z\\s'-]{2,100}$"
    );
    
    private static final Pattern SAFE_TEXT_PATTERN = Pattern.compile(
        "^[A-Za-z0-9\\s.,!?'-]{0,500}$"
    );
    
    private static final Pattern DATE_PATTERN = Pattern.compile(
        "^\\d{4}-\\d{2}-\\d{2}$"
    );
    
    private static final Pattern TIME_PATTERN = Pattern.compile(
        "^\\d{2}:\\d{2}(:\\d{2})?$"
    );
    
    /**
     * Validates email format
     */
    public static boolean isValidEmail(String email) {
        if (email == null || email.trim().isEmpty()) {
            return false;
        }
        return EMAIL_PATTERN.matcher(email.trim()).matches();
    }
    
    /**
     * Validates name (allows letters, spaces, hyphens, apostrophes)
     */
    public static boolean isValidName(String name) {
        if (name == null || name.trim().isEmpty()) {
            return false;
        }
        return NAME_PATTERN.matcher(name.trim()).matches();
    }
    
    /**
     * Validates general text input (prevents XSS and SQL injection)
     */
    public static boolean isValidText(String text) {
        if (text == null) {
            return false;
        }
        return SAFE_TEXT_PATTERN.matcher(text).matches();
    }
    
    /**
     * Validates date format (YYYY-MM-DD)
     */
    public static boolean isValidDate(String date) {
        if (date == null || date.trim().isEmpty()) {
            return false;
        }
        return DATE_PATTERN.matcher(date.trim()).matches();
    }
    
    /**
     * Validates time format (HH:MM or HH:MM:SS)
     */
    public static boolean isValidTime(String time) {
        if (time == null || time.trim().isEmpty()) {
            return false;
        }
        return TIME_PATTERN.matcher(time.trim()).matches();
    }
    
    /**
     * Validates age (must be between 0 and 150)
     */
    public static boolean isValidAge(String ageStr) {
        if (ageStr == null || ageStr.trim().isEmpty()) {
            return false;
        }
        try {
            int age = Integer.parseInt(ageStr.trim());
            return age >= 0 && age <= 150;
        } catch (NumberFormatException e) {
            return false;
        }
    }
    
    /**
     * Validates password strength
     */
    public static boolean isValidPassword(String password) {
        if (password == null) {
            return false;
        }
        // At least 8 characters, contains letter and number
        return password.length() >= 8 && 
               password.matches(".*[A-Za-z].*") && 
               password.matches(".*[0-9].*");
    }
    
    /**
     * Sanitizes text input to prevent XSS
     */
    public static String sanitizeHtml(String input) {
        if (input == null) {
            return null;
        }
        return input
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&#x27;")
            .replace("/", "&#x2F;");
    }
    
    /**
     * Validates and sanitizes input for SQL (though PreparedStatement should be used)
     */
    public static String sanitizeForSQL(String input) {
        if (input == null) {
            return null;
        }
        // Remove potential SQL injection characters
        return input.replaceAll("[';\"\\\\--]", "");
    }
    
    /**
     * Validates integer input
     */
    public static boolean isValidInteger(String input) {
        if (input == null || input.trim().isEmpty()) {
            return false;
        }
        try {
            Integer.parseInt(input.trim());
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
    
    /**
     * Validates that a string doesn't exceed max length
     */
    public static boolean isValidLength(String input, int maxLength) {
        if (input == null) {
            return true; // null is considered valid for length check
        }
        return input.length() <= maxLength;
    }
}